public class SLL {
    Node head; // Head node of the SLL

    // Method to insert a new node at the beginning
    public void insertAtBegin(int data) {
        Node newNode = new Node(data);
        newNode.nextNode = head;
        head = newNode;
    }

    // Method to calculate the sum of data in all nodes
    public int getSum() {
        return getSumRecursive(head);
    }

    // Recursive helper method to calculate sum
    private int getSumRecursive(Node current) {
        if (current == null) {
            return 0;
        }
        return current.data + getSumRecursive(current.nextNode);
    }

    // Method to display the contents of the SLL
    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.nextNode;
        }
        System.out.println();
    }

    // Node class (inner class)
    static class Node {
        int data;
        Node nextNode;

        Node(int d) {
            data = d;
            nextNode = null;
        }
    }
}
