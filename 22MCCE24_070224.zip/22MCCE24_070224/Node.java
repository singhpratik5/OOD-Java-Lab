public class Node {
    Node nextNode;
    int data;

    Node(int d){ //Sets data to d and next to null.
        data = d;
        nextNode = null;
    }
    Node(int d, Node n){ //Sets data to d and next to n
        data = d;
        nextNode = n;
    }
    int getSum(){  //Returns the sum of all nodes in the SLL It is a recursive function.
        //int sum = 0;
        if(nextNode == null)
        {
            return data;
        }
        return data + nextNode.getSum();
    } 
 
    void setNext(Node n){
        nextNode = n;
    }
}
