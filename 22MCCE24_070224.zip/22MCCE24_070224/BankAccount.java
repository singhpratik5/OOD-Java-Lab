import java.util.Random;
import java.util.Scanner;
//import java.util.random.*;
public class BankAccount{

private String name;
private static int DepositAmount;
private final float interestRate = 7.5f;
private int pin;
private static int AccountNumber;
private int Amount;

BankAccount(){
    Random random = new Random();
    AccountNumber = random.nextInt(10000,30000);
    System.out.println("Enter the pin in between 1000 to 9999");
    Scanner sc = new Scanner(System.in);
    pin = sc.nextInt();
    if(pin <1000 || pin >9999){
        System.out.println("Pin must be 4 digit only");
        System.out.print("Enter again");
        pin = sc.nextInt();
    }
    System.out.println("Enter the initial deposit amount: Greater than 1000");
    DepositAmount = sc.nextInt();
    if(DepositAmount<1000){
        System.out.println("Amount must be greater than 1000. Enter again :");
        DepositAmount = sc.nextInt();
    }
    else{
        this.Amount = this.Amount + DepositAmount;
    }
}
    public void deposit(int Amount){
        if(Amount <=0)
            System.out.println("Amount can not be negative or zero");
        this.Amount = Amount + this.Amount;
        System.out.println(Amount+"Deposited, Current Balance :" + this.Amount);
    }

    public int withdraw(int PIN, int Amount){
        if(PIN == this.pin)
        {
            if(this.Amount >= Amount){
                this.Amount = this.Amount - Amount;
                return Amount;
            }
            else{
                    System.out.println("Account Balance low");
                    return 0;
            }
        }
        else{
            System.out.println("Pin didn't match");
        }
        return 0;
    }

    public void displayAccount(int PIN){
        if(PIN == this.pin){
            System.out.println("Current Balance :" + this.Amount);
        }
        else{
            System.out.println("Pin didn't match");
        }
    }
}
