import java.util.Scanner;
public class UseBankAccount {
    public static void main(String[] args) {
        BankAccount Ac1= new BankAccount();

    int choose,i=1;
    Scanner sc = new Scanner(System.in);
    System.out.println("1.Deposit Amount 2. Withdraw Balance  3.Display Balance 4. Exit:");
    //choose = sc.nextInt();
    while(i==1)
    {
        System.out.println("Choose the optons to perform operations :");
        choose = sc.nextInt();
    switch(choose)
    {
        

        case 1:
        System.out.println("Enter the Amount to Deposit");
        int amount = sc.nextInt();
        Ac1.deposit(amount);
        break;

        case 2:
        System.out.println("Enter the Amount to withdraw");
        int Amount = sc.nextInt();
        System.out.println("Enter the Pin");
        int pin = sc.nextInt();
        System.out.println("Withdrawed amount = " + Ac1.withdraw(pin, Amount));
        break;

        case 3:
        System.out.println("Enter the Pin");
        int PIN = sc.nextInt();
        Ac1.displayAccount(PIN);
        break;

        case 4:
        i = 0;
        System.out.println("Process Terminated : Thank You");
    }
    }
}
}
