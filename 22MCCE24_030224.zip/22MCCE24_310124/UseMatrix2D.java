import java.util.*;
import java.util.Scanner;
public class UseMatrix2D {
    
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Matrix2D b = new Matrix2D();
        System.out.println("Enter rows and columns:");
        int rows = sc.nextInt();
        int cols = sc.nextInt();
        Matrix2D a = new Matrix2D(rows,cols);
        //Matrix2D c = new Matrix2D(3,3);
        int row=0,col=0;
        int choose;
        System.out.println("Choose an option to perform operations");
        System.out.println("1. display 2. add 3. multiply");

        choose = sc.nextInt();
        switch(choose)
        {
            case 1: a.display();
            break;
            
            case 2: 
            System.out.println("Enter rows and colums :");
            row = sc.nextInt();
            col = sc.nextInt();
            if(col != a.col || row != a.row)
            {
                System.out.println("Matrix cannot be addded becase rows and columns are different");
                break;
            }
            int data[][] = new int[row][col];
            System.out.println("Enter the elements of the 2nd matrix ");
            for(int i = 0;i<row;i++)
            {
                for(int j = 0;j<col;j++)
                {
                    data[i][j] = sc.nextInt();
                }
            }
            //Matrix2D c = new Matrix2D();
            a.data = a.add(data,row,col);
            a.display();
            break;

            case 3: 
            System.out.println("Enter rows and colums :");
            row = sc.nextInt();
            col = sc.nextInt();
            int data2[][] = new int[row][col];
            if(col != a.col || row != a.row)
            {
                System.out.println("Matrix cannot be multiplied becase col1 != row2");
                break;
            }
            
            System.out.println("Enter the elements of the 2nd matrix ");
            for(int i = 0;i<row;i++)
            {
                for(int j = 0;j<col;j++)
                {
                    data2[i][j] = sc.nextInt();
                }
            }
            a.data = a.multiply(data2,row,col);
            a.display();
            break;
        }
    }
}
