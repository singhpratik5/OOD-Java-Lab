import java.util.*;
import static java.lang.Math.*;
import java.util.Scanner;
public class UseComplex {
    public static void main(String args[])
    {
        Complex a = new Complex(2,4);
        Complex b = new Complex(3,6);
        Complex c = a.addTo(b);
        //c.display();
        
        int choose;
        System.out.println("Choose an option to perform operations");
        Scanner sc = new Scanner(System.in);
        while(true){
        System.out.println("1.add  2.multiply 3.Modulus 4.Check Equal 5.Display 6.Exit");
        choose = sc.nextInt();
        switch(choose){
            case 1: a.addTo(b).display();
            break;
            case 2: a.multiply(b).display();
            break;
            case 3: System.out.println(a.getModulus());
            break;
            case 4: System.out.println(a.equalsTo(b));
            break;
            case 5: a.display();
            break;
            case 6: return;
        }
    }
    }
}
