import java.util.*;
import static java.lang.Math.*;

public class Complex {
  
    double real;
    double img;

    public Complex(double x,double y){
        this.real = x;
        this.img = y;
    };

    public Complex(double x){
        this.real = x;
        this.img = 0;
    };

    public Complex(){
        this.img = 0;
        this.real = 0;
    };

    Complex addTo(Complex b){
        Complex c = new Complex();
        c.real = this.real + b.real;
        c.img = this.img + b.img;
        return c;
    };
    Complex multiply(Complex b){
        Complex c = new Complex();
        c.real = this.real*b.real - this.img*b.img;
        c.img = this.real*b.img + this.img*b.real;
        return c;
    };

    double getModulus(){
        double result = sqrt(this.img*this.img + this.real*this.real);
        return result;
    };
    boolean equalsTo(Complex b)
    {
        if(this.real == b.real && this.img == b.img)
        return true;
        else
        return false;
    }
    void display()
    {
        System.out.println(this.real + " + i" + this.img);
        return;
    }
}
