import static java.lang.Math.nextUp;

public class SLL {
    Node head; // Head node of the SLL

    //Method to delete data node from beginning
    public int deleteAtBegin(){
        int data = head.data;
        Node newNode = head.nextNode;
        head = null;
        head = newNode;
        return data;
    }
    //method to insert at end
    public void insertAtEnd(int d){
        Node newNode = new Node(d);
        if(head == null){
            head = newNode;
        }
        else{
            Node current = head;
        while(current.nextNode!= null)
            current = current.nextNode;

          current.nextNode = newNode;
        }
        newNode.nextNode = null;
    }
    
//Method to delete by value
public void deleteByValue(int d) {
    Node current = head;
    Node prev = null;

    // Traverse the list to find the node with the given value
    while (current != null && current.data != d) {
        prev = current;
        current = current.nextNode;
    }

    // If the value was found, adjust the pointers
    if (current != null) {
        if (prev == null) {
            // If the value is in the head node
            head = current.nextNode;
        } else {
            // If the value is in a non-head node
            prev.nextNode = current.nextNode;
        }
    }
}
    // Method to insert a new node at the beginning
    public void insertAtBegin(int data) {
        Node newNode = new Node(data);
        newNode.nextNode = head;
        head = newNode;
    }

    // Method to calculate the sum of data in all nodes
    public int getSum() {
        return getSumRecursive(head);
    }

    // Recursive helper method to calculate sum
    private int getSumRecursive(Node current) {
        if (current == null) {
            return 0;
        }
        return current.data + getSumRecursive(current.nextNode);
    }

    // Method to display the contents of the SLL
    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.nextNode;
        }
        System.out.println();
    }

    // Node class (inner class)
    static class Node {
        int data;
        Node nextNode;

        Node(int d) {
            data = d;
            nextNode = null;
        }
    }
}
