import java.util.Scanner;

public class Book {
    public String name;
    public String author;
    Page[] pages = new Page[100]; 
    int npage ;
    public Book( String n, String au){
        name = n;
        author = au;
        Scanner s = new Scanner(System.in);
        System.out.print("How many Pages you want to write : ");
        npage = s.nextInt();
        s.nextLine();
        for (int i = 0; i < npage ; i++) {
            System.out.println("\nEnter Content of page no. "+(i+1));
            String str = s.nextLine();
            Page page = new Page(str);
            pages[i] = page;
        }
    }

    public boolean search(String key){
        for (int i = 0; i < npage; i++) {
            if( pages[i].search(key) ){
                return true;
            }
        }
        return false;
    }

    public int searchoc( String key){
        int count = 0;
        for (int i = 0; i < npage; i++) {
            count += pages[i].searchoc(key);
        }
        return count;
    }
}