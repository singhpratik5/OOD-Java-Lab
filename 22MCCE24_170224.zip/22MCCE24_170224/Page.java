public class Page {
    public String str ; 
    
    public Page( String s){
        str = s.toLowerCase();
    }

    public boolean search( String key ){
        int len = key.length();
        if ( str.length() < len) {
            return false;
        }
        for (int i = 0; i < str.length(); i++) {
            if( str.charAt(i) == key.charAt(0) ){
                for (int j = 1; j < len; j++) {
                    if (str.charAt(i+j) != key.charAt(j)) {
                        return false;
                    }
                }
                return true;
            }
        }
        return true;
    }

    public int searchoc( String key ){
        int len = key.length();
        if ( str.length() < len) {
            return 0;
        }
        int count= 0;
        for (int i = 0; i < str.length(); i++) {
            if( str.charAt(i) == key.charAt(0) ){
                int j = 0;
                for (j = 1; j < len; j++) {
                    if (str.charAt(i+j) != key.charAt(j)) {
                        break;
                    }
                }
                if ( j == len) {
                    count++;
                }
            }
        }
        return count;
    }
}
