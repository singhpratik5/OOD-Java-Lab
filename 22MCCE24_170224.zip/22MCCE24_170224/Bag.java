import java.util.Scanner;

public class Bag {
    Book[] books = new Book[10];
    int nbook;
    public Bag(){
        Scanner s = new Scanner(System.in);
        System.out.print("\nEnter the number books :");
        nbook = s.nextInt();
        s.nextLine();
        System.out.println();
        for (int i = 0; i < nbook; i++) {
            System.out.println("\nFor book no. "+(i+1)+"\n");
            System.out.print("Enter author name : ");
            String au = s.nextLine();
            System.out.print("Enter Name of book : ");
            String n = s.nextLine();
            Book book = new Book(n, au);
            books[i] = book;
        }
    }

    public void search(String key){
        for (int i = 0; i < nbook; i++) {
            if ( books[i].search(key)) {
                System.out.println("Name : "+books[i].name);
                System.out.println("Author : "+books[i].author);
            }
        }
    }

    public void searchoc( String key){
        Book maxbook = null;
        int max = 0;

        for (int i = 0; i < nbook; i++) {
            int oc = books[i].searchoc(key);
            if ( max < oc ){
                max = oc;
                maxbook = books[i];
            }
        }
        if( maxbook == null){
            System.out.println("Book not found !!");
        }
        else{
            System.out.println("Name of book : "+maxbook.name);
            System.out.println("Author of book : "+maxbook.author);
        }
    }
}
