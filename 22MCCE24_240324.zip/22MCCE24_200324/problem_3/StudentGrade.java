class StudentGrade {
    private final int rollNo;
    private final String name;
    private final String grade;
    private final double cgpa;

    public StudentGrade(int rollNo, String name, String grade, double cgpa) {
        this.rollNo = rollNo;
        this.name = name;
        this.grade = grade;
        this.cgpa = cgpa;
    }

    public int getRollNo() {
        return rollNo;
    }

    public String getName() {
        return name;
    }

    public String getGrade() {
        return grade;
    }

    public double getCgpa() {
        return cgpa;
    }

    @Override
    public String toString() {
        return "Roll No: " + rollNo + ", Name: " + name + ", Grade: " + grade + ", CGPA: " + cgpa;
    }
}
