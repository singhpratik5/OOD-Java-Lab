import java.util.*;

public class StudentManagementApp {
    private static final Scanner scanner = new Scanner(System.in);
    private static final List<StudentGrade> studentGrades = new ArrayList<>();

    public static void main(String[] args) {
        while (true) {
            System.out.println("\n1. Accept Student Grades");
            System.out.println("2. Search Student Grade by Roll No");
            System.out.println("3. Exit");
            System.out.print("Choose an option: ");

            int option = scanner.nextInt();
            scanner.nextLine(); 

            switch (option) {
                case 1:
                    acceptStudentGrades();
                    break;
                case 2:
                    searchStudentGrade();
                    break;
                case 3:
                    System.out.println("Exiting the program.");
                    return;
                default:
                    System.out.println("Invalid option. Please try again.");
            }
        }
    }

    private static void acceptStudentGrades() {
        System.out.print("Enter the number of student grade details to capture: ");
        int n = scanner.nextInt();
        scanner.nextLine(); 

        if (n <= 0) {
            throw new IllegalArgumentException("N must be > 0");
        }

        List<String> errorMessages = new ArrayList<>();
        for (int i = 0; i < n; i++) {
            System.out.println("Enter details for student #" + (i + 1));
            System.out.print("Roll No: ");
            int rollNo = scanner.nextInt();
            scanner.nextLine(); 
            System.out.print("Name: ");
            String name = scanner.nextLine();
            System.out.print("Grade: ");
            String grade = scanner.nextLine();
            System.out.print("CGPA: ");
            double cgpa = scanner.nextDouble();
            scanner.nextLine(); 

            if (rollNo <= 0) {
                errorMessages.add("Row #" + (i + 1) + "\nRoll No must be a positive integer");
            }
            if (name.isEmpty()) {
                errorMessages.add("Row #" + (i + 1) + "\nName must be non-empty");
            }

            if (errorMessages.isEmpty()) {
                studentGrades.add(new StudentGrade(rollNo, name, grade, cgpa));
            } else {
                throw new IncompleteGradeDetailsException(errorMessages);
            }
        }

        if (errorMessages.isEmpty()) {
            System.out.println("The student grade details are successfully processed");
        }
    }

    private static void searchStudentGrade() {
        System.out.print("Enter Roll No to search: ");
        int rollNo = scanner.nextInt();
        scanner.nextLine(); 

        if (rollNo <= 0) {
            throw new IllegalArgumentException("Roll No must be a positive integer");
        }

        for (StudentGrade studentGrade : studentGrades) {
            if (studentGrade.getRollNo() == rollNo) {
                System.out.println(studentGrade);
                return;
            }
        }

        throw new IncorrectRollNoException("Roll No " + rollNo + " does not exist in the system");
    }
}


class IncompleteGradeDetailsException extends RuntimeException {
    private final List<String> errorMessages;

    public IncompleteGradeDetailsException(List<String> errorMessages) {
        this.errorMessages = errorMessages;
    }

    @Override
    public String getMessage() {
        return String.join("\n", errorMessages);
    }
}

class IncorrectRollNoException extends RuntimeException {
    public IncorrectRollNoException(String message) {
        super(message);
    }
}
