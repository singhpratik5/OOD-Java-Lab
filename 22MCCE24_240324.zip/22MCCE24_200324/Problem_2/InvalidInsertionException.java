package My_Project.Problem_2;

public class InvalidInsertionException extends Exception{
    public InvalidInsertionException(String message){
        super(message);
    }
}
