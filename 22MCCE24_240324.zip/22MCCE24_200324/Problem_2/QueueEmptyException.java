package My_Project.Problem_2;

public class QueueEmptyException extends Exception{
    public QueueEmptyException(String message) {
        super(message);
    }
}
