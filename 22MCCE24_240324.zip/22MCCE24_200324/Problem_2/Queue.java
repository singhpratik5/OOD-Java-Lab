//package My_Project.Problem_2;

import java.util.LinkedList;

public class Queue {
    private LinkedList<Integer> queue;
    private int maxSize;

    public Queue(int maxSize) {
        this.maxSize = maxSize;
        queue = new LinkedList<>();
    }

    public void enqueue(int item) throws QueueFullException {
        if (queue.size() == maxSize) {
            throw new QueueFullException("Queue is full. Cannot enqueue.");
        }
        queue.addLast(item);
    }

    public int dequeue() throws QueueEmptyException {
        if (queue.isEmpty()) {
            throw new QueueEmptyException("Queue is empty. Cannot dequeue.");
        }
        return queue.removeFirst();
    }
}

class QueueFullException extends Exception {
    public QueueFullException(String message) {
        super(message);
    }
}

class QueueEmptyException extends Exception {
    public QueueEmptyException(String message) {
        super(message);
    }
}


