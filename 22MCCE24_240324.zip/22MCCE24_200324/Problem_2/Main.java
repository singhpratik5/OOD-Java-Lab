public class Main {
    public static void main(String[] args) {
        Queue queue = new Queue(5);
        SortedSLL sortedSLL = new SortedSLL();

        try {
            queue.enqueue(10);
        } catch (QueueFullException e) {
            e.printStackTrace();
        }

        try {
            int data = queue.dequeue();
        } catch (QueueEmptyException e) {
            e.printStackTrace();
        }

       
        try {
                sortedSLL.insertAtBegin(10);
            } catch (InvalidInsertionException e) {
                e.printStackTrace();
            }
    
            try {
                sortedSLL.insertAtEnd(20);
            } catch (InvalidInsertionException e) {
                e.printStackTrace();
            }
            
        }
        
    }

