//package My_Project.Problem_2;

public class SortedSLL {
    public Node head;

    public SortedSLL() {
        head = null;
    }

    public void insertAtBegin(int data) throws InvalidInsertionException {
        if (head != null && data > head.data) {
            throw new InvalidInsertionException("Cannot insert at the beginning. It violates the sorted order.");
        }
        Node newNode = new Node(data);
        newNode.next = head;
        head = newNode;
    }

    public void insertAtEnd(int data) throws InvalidInsertionException {
        if (head == null) {
            head = new Node(data);
            return;
        }
        
        Node current = head;
        while (current.next != null) {
            current = current.next;
        }
        
        if (data < current.data) {
            throw new InvalidInsertionException("Cannot insert at the end. It violates the sorted order.");
        }
        
        Node newNode = new Node(data);
        current.next = newNode;
    }

    private class Node {
        int data;
        Node next;

        Node(int data) {
            this.data = data;
            this.next = null;
        }
    }
}

class InvalidInsertionException extends Exception {
    public InvalidInsertionException(String message) {
        super(message);
    }
}
