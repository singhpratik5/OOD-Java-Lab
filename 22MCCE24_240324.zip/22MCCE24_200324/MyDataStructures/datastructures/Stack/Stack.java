package datastructures.Stack;

import java.util.List;
import java.util.ArrayList;
import java.util.EmptyStackException;

public class Stack {
    private List<Integer> stack;

    public Stack() {
        stack = new ArrayList<>();
    }

    // Push an element onto the stack
    public void push(int item) {
        stack.add(item);
    }

    // Pop an element from the stack
    public int pop() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return stack.remove(stack.size() - 1);
    }

    // Peek at the top element without removing it
    public int peek() {
        if (isEmpty()) {
            throw new EmptyStackException();
        }
        return stack.get(stack.size() - 1);
    }

    // Check if the stack is empty
    public boolean isEmpty() {
        return stack.isEmpty();
    }

    // Get the size of the stack
    public int size() {
        return stack.size();
    }

    // Clear the stack
    public void clear() {
        stack.clear();
    }
}
