package mainmethods;

import datastructures.Stack.Stack;
import java.util.EmptyStackException;

public class Main_Stack {
    public static void main(String[] args) {
        Stack stack = new Stack();

        // Demonstrate pushing items onto the stack
        System.out.println("Pushing items onto the stack:");
        stack.push(1);
        stack.push(2);
        stack.push(3);
        System.out.println("Current stack: " + stack);

        // Demonstrate popping items from the stack
        try {
            System.out.println("\nPopping items from the stack:");
            System.out.println("Popped item: " + stack.pop());
            System.out.println("Popped item: " + stack.pop());
            System.out.println("Current stack: " + stack);
        } catch (EmptyStackException e) {
            System.out.println(e.getMessage());
        }

        // Demonstrate peeking at the top item of the stack
        try {
            System.out.println("\nPeeking at the top item of the stack:");
            System.out.println("Top item: " + stack.peek());
            System.out.println("Current stack: " + stack);
        } catch (EmptyStackException e) {
            System.out.println(e.getMessage());
        }

        // Demonstrate checking if the stack is empty
        System.out.println("\nChecking if the stack is empty:");
        System.out.println("Is the stack empty? " + stack.isEmpty());

        // Demonstrate clearing the stack
        System.out.println("\nClearing the stack:");
        stack.clear();
        System.out.println("Is the stack empty after clearing? " + stack.isEmpty());
    }
}
