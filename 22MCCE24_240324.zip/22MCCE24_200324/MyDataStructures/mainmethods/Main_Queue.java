package mainmethods;
import datastructures.Queue;
import java.util.Scanner;

public class Main_Queue {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Queue queue = new Queue(); // Assuming Queue is a previously defined class
        int choice;

        while (true) {
            System.out.println("\n---Queue Operations---");
            System.out.println("1. Enqueue");
            System.out.println("2. Dequeue");
            System.out.println("3. Display");
            System.out.println("4. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1: // Enqueue operation
                    System.out.print("Enter integer element to insert: ");
                    int element = scanner.nextInt();
                    queue.enQueue(element);
                    break;
                case 2: // Dequeue operation
                    int dequeuedElement = queue.deQueue();
                    if (dequeuedElement != -1) {
                        System.out.println("Dequeued Element: " + dequeuedElement);
                    }
                    break;
                case 3: // Displaying the queue
                    queue.display();
                    break;
                case 4: // Exit
                    System.out.println("Exiting...");
                    scanner.close();
                    return;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
            }
        }
    }
}
