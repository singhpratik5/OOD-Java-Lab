package mainmethods;

import datastructures.SLL.LinkedList;

public class Main_LinkedList {
    public static void main(String[] args) {
        LinkedList linkedList = new LinkedList();

        // Demonstrate inserting items at the end of the list
        System.out.println("Inserting items at the end of the list:");
        linkedList.insertAtEnd(1);
        linkedList.insertAtEnd(2);
        linkedList.insertAtEnd(3);
        linkedList.display();

        // Demonstrate inserting an item at the beginning of the list
        System.out.println("\nInserting an item at the beginning of the list:");
        linkedList.insertAtBegin(0);
        linkedList.display();

        // Demonstrate deleting an item by value
        System.out.println("\nDeleting an item by value (2):");
        linkedList.deleteByValue(2);
        linkedList.display();

        // Demonstrate deleting the first item
        System.out.println("\nDeleting the first item:");
        linkedList.deleteAtBegin();
        linkedList.display();

        // Demonstrate calculating the sum of all items
        System.out.println("\nCalculating the sum of all items:");
        System.out.println("Sum: " + linkedList.getSum());
    }
}
