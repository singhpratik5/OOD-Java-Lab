import java.util.Scanner;;
public class UseKVDataStore {
    public static void main(String[] args) {
        try {
            Integer[] keys = {1, 2, 3};
            String[] values = {"One", "Two", "Three"};
            KVDataStore<Integer, String> kvStore = new KVDataStore<>(keys, values);
            
            Scanner scanner = new Scanner(System.in);
            boolean running = true;
            
            while (running) {
                System.out.println("Choose an operation:");
                System.out.println("1. Put key-value pair");
                System.out.println("2. Get value by key");
                System.out.println("3. Display table");
                System.out.println("4. Exit");
                int choice = scanner.nextInt();
                
                switch (choice) {
                    case 1:
                        System.out.println("Enter key:");
                        int key = scanner.nextInt();
                        System.out.println("Enter value:");
                        String value = scanner.next();
                        kvStore.put(key, value);
                        break;
                    case 2:
                        System.out.println("Enter key:");
                        int getKey = scanner.nextInt();
                        String retrievedValue = kvStore.get(getKey);
                        if (retrievedValue != null) {
                            System.out.println("Value for key " + getKey + ": " + retrievedValue);
                        } else {
                            System.out.println("Key not found.");
                        }
                        break;
                    case 3:
                        kvStore.displayTable();
                        break;
                    case 4:
                        running = false;
                        break;
                    default:
                        System.out.println("Invalid choice. Please enter a number between 1 and 4.");
                }
            }
            
            scanner.close();
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
}
