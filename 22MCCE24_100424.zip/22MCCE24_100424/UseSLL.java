import java.util.Scanner;

public class UseSLL {
    public static void main(String[] args) {
        SLL<Integer> sll = new SLL<>();
        Scanner scanner = new Scanner(System.in);

        boolean run = true;
        while (run) {
            System.out.println("Choose an operation:");
            System.out.println("1. Insert data");
            System.out.println("2. Display list");
            System.out.println("3. Exit");
            int choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.println("Enter data:");
                    int data = scanner.nextInt();
                    sll.insert(data);
                    break;
                case 2:
                    System.out.println("List:");
                    sll.display();
                    break;
                case 3:
                    run = false;
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a number between 1 and 3.");
            }
        }

        scanner.close();
    }
}
