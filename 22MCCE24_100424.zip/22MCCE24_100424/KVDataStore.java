public class KVDataStore<T,V>{
    private T[] keyArray;
    private V[] valueArray;
    private int length;
    private int top;

    public KVDataStore(T[] kArray, V[] vArray) throws Exception{
        if(kArray.length != vArray.length){
            throw new Exception(" Key and value arrays size should be same only");
        }
        this.keyArray = kArray;
        this.valueArray = vArray;
        this.length = kArray.length;
        this.top = -1;
    }

    public void put(T a, V b){
        int index = findIndex(a);
        if(index != -1){
            valueArray[index] = b;
        }
        else{
            top++;
            keyArray[top] = a;
            valueArray[top] = b;
        }
    }

    public V get(T a){
        int index = findIndex(a);
        if(index != -1){
            return valueArray[index];
        }
        return null;
    }

    private int findIndex(T key){
        for(int i = 0;i<=top;i++){
            if(keyArray[i].equals(key)){
                return i;
            }
        }
        return -1;
    }

    public void displayTable(){
        System.out.println("Key \tValue");
        for(int i = 0;i<= top ;i++){
            System.out.println(keyArray[i].toString() + "\t" + valueArray[i].toString());
        }
    }
}
