public class FixedTermDepositAccount extends AbstractAccount{
    FixedTermDepositAccount(){
    }
    @Override
    public void deposit(String AccountNumber, double Amount) {
        super.deposit(AccountNumber, Amount);
        Balance = Balance + Amount;
    }
    @Override
    public void applyInterest(String AccountNumber) {
       
        super.applyInterest(AccountNumber);
        Balance = Balance + (Interest*Balance)/100;
    }
}
