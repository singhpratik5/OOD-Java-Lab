public interface Account {
    //private int AccountNumber;

    public void deposit(String AccountNumber,double depositMoney);
    public void applyInterest(String AccountNumber);
}