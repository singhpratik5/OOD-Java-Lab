public interface WithdrawableAccount {
    public double withdraw(String AccountNumber,double Amount);
}