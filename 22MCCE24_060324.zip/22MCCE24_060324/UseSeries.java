/* 
 * Write a description of class UseSeries here.
 *
 * @author : Pratik Singh 
 * @version 06.03.24
 */
import java.util.Scanner;

public class UseSeries
{
    public static void printSeries(Series a, int howmany){
        for (int i=0;i<howmany;i++){
            System.out.println("Next number in Series: "+a.getNext());
        }
    }
    
    public static void main(String[] args){
        Series twoSeries = new ByTwos();
        Series threeSeries = new ByThrees();

        //Printing three series.
        System.out.println("three series :");
        printSeries(threeSeries, 5);

        System.out.println("two series :");
        //printing two series.
        printSeries(twoSeries, 5);
}
}

//UseSeries.java
//Displaying UseSeries.java. UseSeries {   }
