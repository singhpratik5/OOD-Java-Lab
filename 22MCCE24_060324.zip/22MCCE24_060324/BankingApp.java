import java.util.*;
import java.util.ArrayList;
import java.util.List;

public class BankingApp {

     private List<AbstractAccount> accounts = new ArrayList<>();

    public static void main(String[] args) {
        BankingApp bankingApp = new BankingApp();
        bankingApp.run();
    }

    public void run() {
        Scanner scanner = new Scanner(System.in);
        int choice;

        do {
            System.out.println("\n*** Banking System Application ***");
            System.out.println("1. Display all account details");
            System.out.println("2. Search by account number");
            System.out.println("3. Deposit amount");
            System.out.println("4. Withdraw amount");
            System.out.println("5. Apply interest rate");
            System.out.println("6. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    listAllAccounts();
                    break;
                case 2:
                    searchByAccountNumber();
                    break;
                case 3:
                    deposit();
                    break;
                case 4:
                    withdraw();
                    break;
                case 5:
                    applyInterestRate();
                    break;
                case 6:
                    System.out.println("Exiting the application. Thank you!");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 6);
    }

    public void listAllAccounts(){

    }
    public void searchByAccountNumber(){

    }
    //public void depositAmount(){
    //}
    public void withdrawAmount(){

    }
    public void deposit(){
        
    }
   
    public void withdraw(){

    }

    public void applyInterestRate(){

    }
    }

