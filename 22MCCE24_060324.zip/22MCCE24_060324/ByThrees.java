/**
 * Write a description of class ByThrees here.
 * Class ByThrees increment the value by 3 in method getNext.
 *
 * @author Pratik Singh
 * @version 06.03.24
 */
public class ByThrees implements Series
{
    private int start;
    private int val;
    
    public ByThrees(){
        start = 0;
        val = 0;
    }
    
    public int getNext(){
        val +=3;
        return val;
    }
    
    public void reset(){
        val = start;
    }
    
    public void setStart(int x){
        start = x;
        val = x;
    }
    
}