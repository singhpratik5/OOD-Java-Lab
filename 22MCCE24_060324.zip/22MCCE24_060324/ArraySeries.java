public class ArraySeries implements Series {
    private int[] array;
    private int currLocation;

    public ArraySeries(int []array){
        this.array = array;
        this.currLocation = 0;
    }

    @Override
    public int getNext(){
        if(currLocation < array.length){
            int nextValue = array[currLocation];
            currLocation++;
            return nextValue;
        }
        else return -1;
    }

    @Override
    public void reset(){
        currLocation = 0;
    }

    @Override
    public void setStart(int x) {
        if (x >= 0 && x < array.length) {
            currLocation = x;
        } else {
            System.err.println("Invalid index. Location not modified.");
        }
    }
}
