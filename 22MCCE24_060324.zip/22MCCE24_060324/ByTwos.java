
/**
 * Write a description of class ByTwos here.
 * increments the values by two.
 *
 * @author Pratik Singh
 * @version 06.03.24
 */
public class ByTwos implements Series
{
    private int start;
    private int val;
    
    public ByTwos(){
        start = 0;
        val = 0;
    }
    
    public int getNext(){
        val +=2;
        return val;
    }
    
    public void reset(){
        val = start;
    }
    
    public void setStart(int x){
        start = x;
        val = x;
    }
    
}

