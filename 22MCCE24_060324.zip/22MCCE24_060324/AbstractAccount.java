public class AbstractAccount implements Account{
    public String AccountNumber;
    public String Name;
    public String AccountType;
    public double Balance;
    public double Interest;

    AbstractAccount(){
    }
    public String getAccountNumber() {
        return AccountNumber;
    }

    public String getAccountHolderName() {
        return Name;
    }

    public String getAccountType() {
        return AccountType;
    }

    public double getInterestRate() {
        return Interest;
    }

    public double getBalance() {
        return Balance;
    }

    @Override
    public void deposit(String AccountNumber, double Amount) {
        Balance = Balance + Amount;
    }

    @Override
    public void applyInterest(String AccountNumber) {
        Balance = Balance + (Interest*Balance)/100;
    }

}
