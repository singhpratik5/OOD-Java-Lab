public class SavingAccount extends AbstractAccount implements WithdrawableAccount{
    public double withdraw(String AccountNumber,double Amount){
        double withdrewed = 0;
        if(Balance >= Amount){
            Balance = Balance - Amount;
            withdrewed = Amount;
            return withdrewed;
        }
        else{
            System.out.println("Balance is not sufficient");
            return withdrewed;
        }
    }

    @Override
    public void deposit(String AccountNumber, double Amount) {
        super.deposit(AccountNumber, Amount);
        Balance = Balance + Amount;
    }
    @Override
    public void applyInterest(String AccountNumber) {
       
        super.applyInterest(AccountNumber);
        Balance = Balance + (Interest*Balance)/100;
    }
    
}
