import java.util.Scanner;
public class UseShapes {
    public static void main(String[] args) {
        int choose;
        Scanner sc = new Scanner(System.in);
        System.out.println("Choose to perform operations : ");
        System.out.println("1.Triangle Area 2. Rectangle Area 3.isRightAngleTriangle 4. isIsoscelesTriangle 5.isEquilateralTriangle");
        choose = sc.nextInt();
        switch (choose) {
            case 1:
                System.out.print("Enter the height and width of the Triangle");
                double height,width;
                height = sc.nextInt();
                width = sc.nextInt();
                Triangle a = new Triangle(height,width);
                System.out.println("Area is = " + a.getArea());
                break;
            case 2:
            System.out.print("Enter the height and width of the Rectangle");
            height = sc.nextInt();
            width = sc.nextInt();
            Rectangle r = new Rectangle(height,width);
            System.out.println("Area is = " + r.getArea());
                break;
            //More cases i will write them later : Thank You
            default:
                break;
        }
    }
}
