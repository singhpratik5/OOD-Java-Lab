import java.math.*;
public class XYZPoint extends XYPoint{
    private double z;
    public XYZPoint(double tx, double ty, double tz){
        super(tx, ty);
        this.z = tz;
    }
    public double distance3D(XYZPoint other){
        return(Math.sqrt(Math.pow(x-other.x, 2) + Math.pow(y-other.y, 2) + Math.pow(z-other.z, 2)));
    }

    public double getX(){
        return x;
    }
    public double getY(){
        return y;
    }
    public double getZ(){
        return z;
    }
}
