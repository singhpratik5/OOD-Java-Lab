public class Person {
    protected String Name;
    protected int age;

    public Person(String Name,int age)
    {
        this.Name = Name;
        this.age = age;
    }
    public void Display(){
        System.out.println("The name of person is " + Name + "and Age is : " + age );
    }
}
