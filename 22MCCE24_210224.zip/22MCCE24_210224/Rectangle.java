public class Rectangle extends Shapes{
    public Rectangle(double height,double width){
        super(height, width);
    }
    public double getArea(){
        return getHeight()*getWidth();
    }
}
