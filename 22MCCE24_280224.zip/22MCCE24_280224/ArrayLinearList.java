import java.util.Scanner;

public class ArrayLinearList extends LinearList {
    private int[] arr;
    private int size;

    public ArrayLinearList(int n) {
        arr = new int[n];
        size = n;
        Scanner s = new Scanner(System.in);
        for (int i = 0; i < size; i++) {
            System.out.print("Enter element at index " + i + ": ");
            arr[i] = s.nextInt();
        }
    }

    @Override
    public boolean isEmpty() {
        return size == 0;
    }

    @Override
    public int size() {
        return size;
    }

    @Override
    public int get(int index) {
        if (index < 0 || index >= size) {
            return -1;
        }
        return arr[index];
    }

    @Override
    public int indexOf(int theElement) {
        for (int i = 0; i < size; i++) {
            if (theElement == arr[i]) {
                return i;
            }
        }
        return -1;
    }

    @Override
    public int remove(int index) {
        int temp = arr[index];
        arr[index] = 0;
        return temp;
    }

    @Override
    public void add(int index, int theElement) {
        if (index >= 0 && index < size) {
            arr[index] = theElement;
        }
    }
}
