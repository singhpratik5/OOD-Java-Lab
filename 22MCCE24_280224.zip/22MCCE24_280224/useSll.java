import java.util.Scanner;

public class useSll {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int ch = 1;
        SortedSLL link = new SortedSLL();
        int num;
        while (ch != 0) {
            System.out.print(
                    "\n1. Insert\n2. Sum of List\n3. Display\n4. Delete At Bigin\n5. Delete by value\nEnter choice (0 for exit) : ");
            ch = s.nextInt();
            s.nextLine();
            switch (ch) {
                case 0:
                    break;
                case 1:
                    System.out.println("Enter a Number : ");
                    num = s.nextInt();
                    link.insertInOrder(num);
                    break;
                case 2:
                    System.out.println("Sum : " + link.getSum());
                    break;
                case 3:
                    link.display();
                    break;
                case 4:
                    System.out.println(link.deleteAtBigin());
                    break;
                case 5:
                    System.out.println("Enter a Number : ");
                    num = s.nextInt();
                    link.deleteByValue(num);
                    break;
                default:
                    System.out.println("Invalid choice");
                    break;
            }
        }
        s.close();
    }
}
