public class sll extends LinearList {
    private node head = null;
    private int size = 0 ;

    public void insertAtBegin(int d) {
        node temp = new node(d);
        temp.setnext(head);
        head = temp;
        size++;
    }

    public int getSum() {
        if (head == null) {
            return 0;
        } else
            return head.getSum();
    }

    public void display() {
        if (head == null) {
            System.out.println("Empty");
        } else {
            head.display();
        }
    }

    public boolean isEmpty() {
        if (head == null)
            return true;
        else
            return false;
    };

    public int size() {
        return size;
    };

    public int get(int index){
        if (index >= size) {
            return -1;
        }
        node temp = head;
        for (int i = 0; temp != null && i < index; i++) {
            temp = temp.getnext();
        }
        if (temp == null){
            return -1;
        }
        return temp.getdata();
    };

    public int indexOf(int theElement){
        int i = 0;
        node temp = head;
        while ( temp != null && temp.getdata() != theElement) {
            temp = temp.getnext();
            i++;
        }
        if (temp == null){
            return -1;
        }
        return i;
    };

    public int remove(int index){
        node temp = head;
        node prev = null;
        for (int i = 0; temp != null && i <= index; i++) {
            prev = temp;
                temp = temp.getnext();
        }
        if (temp == null) {
            return -1;
        }
        prev.setnext(temp.getnext());
        size--;
        return temp.getdata();
    };

    public void add(int index, int theElement){
        node temp = head;
        for (int i = 0; temp != null && i <= index; i++) {
                temp = temp.getnext();
        }
        if (temp == null) {
            System.out.println("Size is small!!");
        }
        temp.setdata( theElement + temp.getdata());
    };
}