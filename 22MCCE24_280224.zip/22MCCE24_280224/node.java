public class node {
    private int data ;
    private node  next;

    public node ( int data){
        this.data = data;
        next = null ;
    }

    public node(int d, node n){
        data = d;
        this.next = n;
    }

    public int getdata( ){
        return data;
    }

    public void setnext( node n){
        this.next = n;
    }

    public void setdata( int num){
        data = num;
    }

    public node getnext(){
        return next;
    }

    public int getSum(){
        if ( next == null){
            return data;
        }
        else {
            return data + next.getSum();
        }
    }

    public void display(){
        System.out.print(data + ", ");
        if ( next != null){
            next.display();
        }
    }
}
