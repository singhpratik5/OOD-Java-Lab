/*public class SortedSLL extends sll {
    
    public SortedSLL(){
        super();
    }

    
    public void insertAtBegin(int d) {
        System.out.println("It can not invoke");
    }
    
    public void insertAtEnd(int d) {
        System.out.println("It can not invoke");
    }
}
*/
class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class SortedSLL {
    Node head;

    public SortedSLL() {
        this.head = null;
    }

    public void insertInOrder(int data) {
        Node new_node = new Node(data);
        if (this.head == null || data < this.head.data) {
            new_node.next = this.head;
            this.head = new_node;
        } else {
            Node current = this.head;
            while (current.next != null && current.next.data < data) {
                current = current.next;
            }
            new_node.next = current.next;
            current.next = new_node;
        }
    }

    public void display() {
        Node current = this.head;
        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }
        System.out.println("None");
    }

    public String deleteAtBigin() {
        if (this.head == null) {
            return "List is empty";
        } else {
            int data = this.head.data;
            this.head = this.head.next;
            return "Deleted value: " + data;
        }
    }

    public String deleteByValue(int value) {
        Node current = this.head;
        Node prev = null;
        while (current != null) {
            if (current.data == value) {
                if (prev != null) {
                    prev.next = current.next;
                } else {
                    this.head = current.next;
                }
                return "Deleted value: " + value;
            }
            prev = current;
            current = current.next;
        }
        return value + " not found in the list";
    }

    public int getSum() {
        Node current = this.head;
        int total = 0;
        while (current != null) {
            total += current.data;
            current = current.next;
        }
        return total;
    }

    // Example usage
    public static void main(String[] args) {
        SortedSLL link = new SortedSLL();
        link.insertInOrder(10);
        link.insertInOrder(5);
        link.insertInOrder(20);
        link.display();
        System.out.println("Sum: " + link.getSum());
        System.out.println(link.deleteAtBigin());
        link.display();
        System.out.println(link.deleteByValue(5));
        link.display();
    }
}
