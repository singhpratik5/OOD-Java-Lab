import java.util.Scanner;

public class UseLinearList {
    public static int getSum(LinearList a) {
        int sum = 0;
        for (int i = 0; true; i++) {
            if (a.get(i) == -1) {
                break;
            } else {
                sum += a.get(i);
            }
        }
        return sum;
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int num;
        int ch = 1;
        while (ch != 0) {
            System.out.println("\n1. Array\n2. Link List \nEnter choice( 0 for exit ) :");
            ch = s.nextInt();
            switch (ch) {
                case 0:
                    break;

                case 1:
                    System.out.println("Enter size of Array : ");
                    num = s.nextInt();
                    ArrayLinearList arr = new ArrayLinearList(num);
                    System.out.println("\n Sum: %d\n" + getSum(arr));
                    break;

                case 2:
                    int ch2 = 1;
                    SLLLinearList lst = new SLLLinearList();
                    while (ch2 != 0) {
                        System.out.println("\n1. Insert\n2. Get Sum \nEnter your choice ( 0 for exit ): ");
                        ch2 = s.nextInt();
                        switch (ch2) {
                            case 0:
                                break;
                            case 1:
                                lst.insert();
                                break;
                            case 2:
                                System.out.println("Sum of Link list : " + getSum(lst));
                                break;
                            default:
                                System.out.println("Invalid choice");
                                break;
                        }
                    }
                    break;

                default:
                    System.out.println("Invalid choice");
                    break;
            }
        }
    }
}
