import java.util.Scanner;

public class SLLLinearList extends LinearList {
    private sll lst = new sll();

    public void insert(){
        System.out.println("Enter a number : ");
        Scanner s = new Scanner(System.in);
        int num = s.nextInt();
        lst.insertAtBegin(num);
    }

    public boolean isEmpty() {
        return lst.isEmpty();
    };
    
    public int size() {
        return lst.size();
    };

    public int get(int index){
        return lst.get(index);
    };

    public int indexOf(int theElement){
        return lst.indexOf(theElement);
    };

    public int remove(int index){
        return lst.remove(index);
    };

    public void add(int index, int theElement){
        lst.add(index, theElement);
    };
}
