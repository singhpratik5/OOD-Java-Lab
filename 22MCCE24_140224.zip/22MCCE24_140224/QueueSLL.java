class Node {
    int data;
    Node next;

    public Node(int d) {
        data = d;
        next = null;
    }
}

class QueueSLL {
    private Node front; // Points to the front (head) of the queue
    private Node rear;  // Points to the rear (tail) of the queue

    public QueueSLL() {
        front = null;
        rear = null;
    }

    // Enqueue (add an element to the rear of the queue)
    public void enqueue(int value) {
        Node newNode = new Node(value);
        if (rear == null) {
            // If the queue is empty, set both front and rear to the new node
            front = newNode;
            rear = newNode;
        } else {
            // Otherwise, add the new node after the current rear
            rear.next = newNode;
            rear = newNode;
        }
    }

    // Dequeue (remove and return the element from the front of the queue)
    public int dequeue() {
        if (front == null) {
            throw new IllegalStateException("Queue is empty");
        }
        int removedValue = front.data;
        front = front.next;
        if (front == null) {
            // If the last element was removed, update rear to null
            rear = null;
        }
        return removedValue;
    }

    // Check if the queue is empty
    public boolean isEmpty() {
        return front == null;
    }

    // Get the size of the queue
    public int size() {
        int count = 0;
        Node current = front;
        while (current != null) {
            count++;
            current = current.next;
        }
        return count;
    }
}
