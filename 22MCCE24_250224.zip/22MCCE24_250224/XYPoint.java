import java.math.*;
public class XYPoint {
    protected double x,y;
    public XYPoint(double tx, double ty){
        this.x = tx;
        this.y = ty;
    }

    public double getX(){
        return x;
    }
    public double getY(){
        return y;
    }
    public void setXY(double tx,double ty){
        this.x = tx;
        this.y = ty;
    }
    public double distance(XYPoint other){
        return Math.sqrt(Math.pow(x - other.x,2) + Math.pow(y - other.y,2));
    }
}
