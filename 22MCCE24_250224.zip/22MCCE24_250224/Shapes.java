public class Shapes{
    private double height;
    private double width;

    public Shapes(double height,double width)
    {
        this.height = height;
        this.width = width;
    }

    public void setValues(double height,double width)
    {
        this.height = height;
        this.width = width;
    }
    public double getHeight()
    {
        return height;
    }
    public double getWidth()
    {
        return width;
    }
}