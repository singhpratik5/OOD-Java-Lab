import java.util.Scanner;
public class UseShapes {
    public static void main(String[] args) {
        int choose =0;
        Scanner sc = new Scanner(System.in);
        double height,width;
        double hypo;
        double perp;
        double base;
        Triangle a = new Triangle(0,0);
        while(choose!=6){
        System.out.println("Choose to perform operations : ");
        System.out.println("1.Triangle Area 2. Rectangle Area 3.isRightAngleTriangle 4. isIsoscelesTriangle 5.isEquilateralTriangle 6. Exit");
        choose = sc.nextInt();
        switch (choose) {
            case 1:
                System.out.print("Enter the height and width of the Triangle");
                height = sc.nextInt();
                width = sc.nextInt();
                Triangle t = new Triangle(height,width);
                System.out.println("Area is = " + t.getArea());
                break;
            case 2:
            System.out.print("Enter the height and width of the Rectangle");
            height = sc.nextInt();
            width = sc.nextInt();
            Rectangle r = new Rectangle(height,width);
            System.out.println("Area is = " + r.getArea());
                break;
            case 3:
            System.out.println("Enter the Hypoteous,perpendicular and base of the Triangle respectively");
            hypo = sc.nextInt();
            perp = sc.nextInt();
            base = sc.nextInt();
            a = new Triangle(0, 0);
            System.out.println(a.isRightAngleTriangle(hypo,perp,base));
            break;
            case 4:
            System.out.println("Enter the Hypoteous,perpendicular and base of the Triangle respectively");
            hypo = sc.nextInt();
            perp = sc.nextInt();
            base = sc.nextInt();
            System.out.println(a.isIsoscelesTriangle(hypo,perp,base));
            break;
            case 5:
            System.out.println("Enter the Hypoteous,perpendicular and base of the Triangle respectively");
            hypo = sc.nextInt();
            perp = sc.nextInt();
            base = sc.nextInt();
            System.out.println(a.isEquilateralTriangle(hypo,perp,base));
            break;
            case 6:
            choose = 6;
            default:
                break;
        }
    }
    }
}
