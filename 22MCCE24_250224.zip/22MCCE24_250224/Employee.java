public class Employee extends Person{
    public Employee(String Name, int age){
        super(Name,age);
    }
    private int id;
    private double HourlyPay;

    public void setID(int id)
    {
        this.id = id;
    } 
    public void setHourlyPay(double HourlyPay){  
        this.HourlyPay = HourlyPay;
    } 
    public double getHourlyPay(){   
        return HourlyPay;
    } 
    public int getID(){
        return id;
    }
    public double getRaise(){
        HourlyPay = HourlyPay*0.15 + HourlyPay;
        return HourlyPay;
    }
    public void Display(){
        System.out.println("The name of person is " + Name + "and Age is : " + age + "Id is : " + id +" With Hourly Pay :" + HourlyPay);
    }
    }
