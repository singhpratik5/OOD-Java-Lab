// I am using width of triangle as base and taking perpendicular and hypotaneous as input.

public class Triangle extends Shapes{
    
    public Triangle(double height,double width){
        super(height, width);
    }

    public double getArea(){
        return 0.5*getHeight()*getWidth();
    }
    public boolean isRightAngleTriangle(double hypo , double perp,double base){

        if(hypo*hypo == perp*perp + base*base){
        return true;
        }
        return false;
    }
    public boolean isIsoscelesTriangle(double hypo, double perp,double base){
        if(hypo == perp || hypo == base || perp == base){
            return true;
        }
        return false;
    }
    public boolean isEquilateralTriangle(double hypo, double perp, double base){
        if(hypo == perp && hypo == base){
            return true;
        }
        return false;
    }
}
