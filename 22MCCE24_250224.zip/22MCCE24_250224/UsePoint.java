import java.util.Scanner;
public class UsePoint {
    public static void main(String[] args) {
        XYPoint a = new XYPoint(0,0);//I am declaring first point as (0,0) in 2d.
        XYZPoint b = new XYZPoint(0, 0, 0);//I am declaring first point as (0,0,0) in 3d.
        int choose = 0;
        Scanner sc = new Scanner(System.in);
        while(choose != 3){
            System.out.println("Choose to perform operations : ");
            System.out.println("1.2D distance 2. 3D distance 3.Exit");
            choose = sc.nextInt();
        switch (choose){
            case 1:
            System.out.println("Enter x and y for other point :");
                double x,y;
                x = sc.nextInt();
                y = sc.nextInt();
                XYPoint otherPoint = new XYPoint(x, y);
                System.out.println("Distance is : " + a.distance(otherPoint));
                break;
            
            case 2:
            System.out.println("Enter x y and z for other point :");
                double z;
                x = sc.nextInt();
                y = sc.nextInt();
                z = sc.nextInt();
                XYZPoint otherPoint2 = new XYZPoint(x, y,z);
                System.out.println("Distance is : " + b.distance(otherPoint2));
                break;
            
            case 3:
            choose = 3;
            return;

            default:
                break;
        
        }
    }
    }
}
