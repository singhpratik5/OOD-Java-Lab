import java.util.Scanner;

public class UsePerson {
    public static void main(String[] args) {
        
        int choose =0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the Name of person:");
        String Name = sc.nextLine();
        System.out.println("Enter the Age of person:");
        int Age = sc.nextInt();
        System.out.println("Enter the id and HourlyPay of Employee:");
        Person P = new Person(Name,Age);
        int id = sc.nextInt();
        double HourlyPay = sc.nextInt();
        Employee E = new Employee(Name, Age);
        E.setID(id);
        E.setHourlyPay(HourlyPay);

        while (choose!=4) {
            System.out.println("1.Display The person 2.Display the Employee 3. GetRaise in Salary 4.Exit");
            choose = sc.nextInt();
            switch (choose) {
                case 1:
                    System.out.println("Name :" + P.Name + "  and age is :" + P.age);
                    break;
                case 2:
                    System.out.println("Name :" + P.Name + "  and age is :" + P.age + " with id - " +id + "  and hourly Pay :" +HourlyPay );
                    break;
                case 3:
                    System.out.println("Now the salary is :" + E.getRaise());
                    break;
                case 4: 
                    choose = 4;
                default:
                    break;
            }
        }
    }
}
