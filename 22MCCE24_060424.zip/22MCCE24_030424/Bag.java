import java.lang.reflect.Array;
import java.util.Arrays;
import java.util.Scanner;

public class Bag implements Cloneable{
    Book[] books = new Book[10];
    int nbook;
    public Bag(){
        Scanner s = new Scanner(System.in);
        System.out.print("\nEnter the number books :");
        nbook = s.nextInt();
        s.nextLine();
        System.out.println();
        for (int i = 0; i < nbook; i++) {
            System.out.println("\nFor book no. "+(i+1)+"\n");
            System.out.print("Enter author name : ");
            String au = s.nextLine();
            System.out.print("Enter Name of book : ");
            String n = s.nextLine();
            Book book = new Book(n, au);
            books[i] = book;
        }
    }
    //Clone method implemented here.
    @Override
    public Object clone() {
        try {
            Bag clonedBag = (Bag) super.clone();
            //clonedBag.books = Arrays.copyOf(books, nbook); // Shallow copy of the array

            // Deep copy each Book object
            for (int i = 0; i < nbook; i++) {
                clonedBag.books[i] = (Book) books[i].clone();
            }

            return clonedBag;
        } catch (CloneNotSupportedException e) {
            throw new InternalError(e);
        }
    }

    public void search(String key){
        for (int i = 0; i < nbook; i++) {
            if ( books[i].search(key)) {
                System.out.println("Name : "+books[i].name);
                System.out.println("Author : "+books[i].author);
            }
        }
    }

    public void searchoc( String key){
        Book maxbook = null;
        int max = 0;

        for (int i = 0; i < nbook; i++) {
            int oc = books[i].searchoc(key);
            if ( max < oc ){
                max = oc;
                maxbook = books[i];
            }
        }
        if( maxbook == null){
            System.out.println("Book not found !!");
        }
        else{
            System.out.println("Name of book : "+maxbook.name);
            System.out.println("Author of book : "+maxbook.author);
        }
    }
}
