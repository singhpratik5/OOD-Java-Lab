import java.util.*;
import java.util.Scanner;

public class Matrix2D{

    int [][] data;
    int row,col;

    Matrix2D()
    {
        this.col = 3;
        this.row = 3;
        this.data = new int[row][col];
    };
    Matrix2D(int[][] data, int nrow,int ncol)
    {
        this.col = ncol;
        this.row = nrow;
        this.data = new int[row][col];
        for(int i = 0;i<3;i++)
        {
            for(int j =0;j<3;j++)
            {
                this.data[i][j] = data[i][j];
            }
        }
    };
    Matrix2D(int nrow, int ncol)
    {
        this.col = ncol;
        this.row = ncol;
        this.data = new int[row][col];
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the elements of the matrix ");
        for(int i = 0;i<row;i++)
        {
            for(int j = 0;j<col;j++)
            {
                data[i][j] = sc.nextInt();
            }
        }
    };

    public void display()
    {
        for(int i = 0;i<row;i++)
        {
            System.out.println(" ");
            for(int j = 0;j<col;j++)
            {
                System.out.print(data[i][j]+" ");
            }
        }
    }

    public int[][] add(int [][]mattrix2,int row,int col)
    {
        int res[][] = new int[row][col];

        for(int i = 0;i<row;i++)
        {
            for(int j = 0;j<col;j++)
            {
                res[i][j] = this.data[i][j] + mattrix2[i][j];
            }
        }
        return res;
    }

    public int[][] multiply(int matrix2[][],int row2,int col2)
    {
        int i,j,k;
        if (row2 != this.col) { 
  
            System.out.println("\nMultiplication Not Possible"); 
            return matrix2; 
        } 
  
        // Matrix to store the result 
        
        int C[][] = new int[this.row][col2]; 
  
        // Multiply the two matrices 

        for (i = 0; i < this.row; i++) { 
            for (j = 0; j < col2; j++) { 
                for (k = 0; k < row2; k++) 
                    C[i][j] += this.data[i][k] * matrix2[k][j];
            } 
        } 
        return C;
    }
};

@Override
public boolean equals(Object o){
    if(this.getClass()!=o.getClass())
        return false;
    else if(this.row != o.row){
        return false;
    }
    else if(this.col != o.col){
        return false;
    }
    return true;
}

