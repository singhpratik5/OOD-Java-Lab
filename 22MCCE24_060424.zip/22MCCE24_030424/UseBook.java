import java.util.Scanner;

public class UseBook {
    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int ch = 1;
        Bag bag = new Bag();
        String key;
        while (ch != 0) {
            System.out.print(
                    "\n1. Search Books by key\n2. Max key Occurance\nEnter choice (0 for exit) : \n3. Clone :");
            ch = s.nextInt();
            s.nextLine();
            switch (ch) {
                case 0:
                    break;
                case 1:
                    System.out.println("Enter key : ");
                    key = s.nextLine();
                    key.toLowerCase();
                    bag.search(key);
                    break;
                    case 2:
                    System.out.println("Enter key : ");
                    key = s.nextLine();
                    key.toLowerCase();
                    bag.searchoc(key);
                    break;
                    case 3:
                    System.out.println("Clonning Bag");
                    bag.clone();
                    break;
                    default:
                    System.out.println("Invalid choice");
                    break;
            }
        }
        s.close();
    }
}
