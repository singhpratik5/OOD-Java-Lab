import java.util.Scanner;
public class UseSLL {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        SLL list = new SLL();

        int choice;
        do {
            System.out.println("\nSingly Linked List Menu:");
            System.out.println("1. Insert at the beginning");
            System.out.println("2. Display");
            System.out.println("3. Sum of data");
            System.out.println("4. Delete at begin");
            System.out.println("5. insert at End");
            System.out.println("6. Delete by value");
            System.out.println("7. Check Is Equal :");
            System.out.println("8. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();

            switch (choice) {
                case 1:
                    System.out.print("Enter data to insert: ");
                    int data = scanner.nextInt();
                    list.insertAtBegin(data);
                    break;
                case 2:
                    System.out.println("Contents of the list:");
                    list.display();
                    break;
                case 3:
                    int sum = list.getSum();
                    System.out.println("Sum of data in the list: " + sum);
                    break;
                case 4:
                    int val = list.deleteAtBegin();
                    System.out.println("Deleted." + val);
                    break;
                case 5:
                    System.out.print("Enter data to insert: ");
                    data = scanner.nextInt();
                    list.insertAtEnd(data);
                    break;
                case 6:
                    System.out.print("Enter data to delete: ");
                    data = scanner.nextInt();
                    list.deleteByValue(data);
                    break;
                case 7:
                    System.out.println("");
                    System.out.print("Enter the second linked list elements (comma-separated): ");
                    scanner.nextLine(); // Consume the newline character
                    String input = scanner.nextLine();
                    String[] elements = input.split(",");
                    SLL otherList = new SLL();

                    // Insert elements into the other linked list
                    for (String element : elements) {
                        int value = Integer.parseInt(element.trim());
                        otherList.insertAtEnd(value);
                    }
                    System.out.println(list.equals(otherList));
                    break;
                case 8:
                    System.out.println("Exiting the program.");
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        } while (choice != 8);

        scanner.close();
    }
}
