import static java.lang.Math.nextUp;

public class SLL {
    Node head; 

//  EQUALS METHOD INSERTED HERE.

@Override
public boolean equals(Object o) {
    if (this == o)
        return true;
    if (o == null || getClass() != o.getClass())
        return false;

    SLL otherList = (SLL) o;

    Node tempNode1 = this.head;
    Node tempNode2 = otherList.head;
    while (tempNode1 != null && tempNode2 != null) {
        if (tempNode1.data != tempNode2.data)
            return false;
        tempNode1 = tempNode1.nextNode;
        tempNode2 = tempNode2.nextNode;
    }
    return tempNode1 == null && tempNode2 == null;
}


    public int deleteAtBegin(){
        int data = head.data;
        Node newNode = head.nextNode;
        head = null;
        head = newNode;
        return data;
    }

    public void insertAtEnd(int d){
        Node newNode = new Node(d);
        if(head == null){
            head = newNode;
        }
        else{
            Node current = head;
        while(current.nextNode!= null)
            current = current.nextNode;

          current.nextNode = newNode;
        }
        newNode.nextNode = null;
    }
    

public void deleteByValue(int d) {
    Node current = head;
    Node prev = null;

    while (current != null && current.data != d) {
        prev = current;
        current = current.nextNode;
    }


    if (current != null) {
        if (prev == null) {
            head = current.nextNode;
        } else {
            // If the value is in a non-head node
            prev.nextNode = current.nextNode;
        }
    }
}
  
    public void insertAtBegin(int data) {
        Node newNode = new Node(data);
        newNode.nextNode = head;
        head = newNode;
    }

    public int getSum() {
        return getSumRecursive(head);
    }

    private int getSumRecursive(Node current) {
        if (current == null) {
            return 0;
        }
        return current.data + getSumRecursive(current.nextNode);
    }

    public void display() {
        Node current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.nextNode;
        }
        System.out.println();
    }

    static class Node {
        int data;
        Node nextNode;

        Node(int d) {
            data = d;
            nextNode = null;
        }
    }
}
