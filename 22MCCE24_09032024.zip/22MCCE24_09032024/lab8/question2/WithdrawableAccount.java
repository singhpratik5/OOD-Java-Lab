public interface WithdrawableAccount extends Account {
    double withdraw( String acc , double mon);
}
