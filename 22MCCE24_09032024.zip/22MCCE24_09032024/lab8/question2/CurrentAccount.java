public class CurrentAccount extends AbstractAccount implements WithdrawableAccount {
    
    public CurrentAccount(String accountNumber, String accountHolderName) {
        super(accountNumber, accountHolderName);
    }
    @Override
    public void deposit(String accountNumber ,double amount) {
        this.balance += amount;
    }

    @Override
    public double withdraw(String accountNumber, double amount) {
        this.balance -= amount;
        return balance;
    }

    @Override
    public void applyInterest(String accountNumber ) {
        this.balance += balance*interest;
    }
}
