public interface Account {

    void deposit( String accnum , double dep);
    void applyInterest( String accnum);
}