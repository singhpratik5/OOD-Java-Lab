public class FixedTermDepositAccount extends AbstractAccount{
    
    public FixedTermDepositAccount(String accountNumber, String accountHolderName) {
        super(accountNumber, accountHolderName);
        interest = 12;
    }

    @Override
    public void deposit(String accountNumber, double amount) {
        if (accountNumber.equals(this.accountNumber))
            this.balance += amount;
        else
            System.out.println("Wrong Acount number");
    }

    @Override
    public void applyInterest(String accountNumber) {
        if (accountNumber.equals(this.accountNumber))
            this.balance += balance * interest;
        else
            System.out.println("Wrong Acount number");
    }
}
