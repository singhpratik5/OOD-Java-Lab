//author : Pratik Singh[22MCCE24]
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BankingApp {
    private static List<AbstractAccount> accounts = new ArrayList<>();

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int ch = 1, ac;
        String name, acno;
        double am;
        while (ch != 0) {
            System.out.print(
                    "\n1. Make New Saving Acoount\n2. New Current Acount\n3. New Fixed Term Deposit Account\n4. List All acount\n5. Deposit\n6. WithDraw Amount\n7. Apply Interest\nEnter your choice ( 0 for Exit ) : ");
            ch = s.nextInt();
            s.nextLine();
            switch (ch) {
                case 0:
                    break;
                case 1:
                    System.out.print("Enter Name : ");
                    name = s.nextLine();
                    ac = (int) (Math.random() * 10000000);
                    acno = Integer.toString(ac);
                    for (int i = 0; i < accounts.size(); i++) {
                        if (accounts.get(i).equals(acno)) {
                            i = -1;
                            ac = (int) (Math.random() * 10000000);
                            acno = Integer.toString(ac);
                        }
                    }
                    addAccount(new SavingAccount(acno, name));
                    break;
                case 2:
                    System.out.print("Enter Name : ");
                    name = s.nextLine();
                    ac = (int) (Math.random() * 10000000);
                    acno = Integer.toString(ac);
                    for (int i = 0; i < accounts.size(); i++) {
                        if (accounts.get(i).equals(acno)) {
                            i = -1;
                            ac = (int) (Math.random() * 10000000);
                            acno = Integer.toString(ac);
                        }
                    }
                    addAccount(new CurrentAccount(acno, name));
                    break;
                case 3:
                    System.out.print("Enter Name : ");
                    name = s.nextLine();
                    ac = (int) (Math.random() * 10000000);
                    acno = Integer.toString(ac);
                    for (int i = 0; i < accounts.size(); i++) {
                        if (accounts.get(i).equals(acno)) {
                            i = -1;
                            ac = (int) (Math.random() * 10000000);
                            acno = Integer.toString(ac);
                        }
                    }
                    addAccount(new FixedTermDepositAccount(acno, name));
                    break;
                case 4:
                    listAllAccounts();
                    break;
                case 5:
                    System.out.print("Enter Account Number : ");
                    acno = s.nextLine();
                    System.out.print("Enter Deposit Amount : ");
                    am = s.nextInt();
                    deposit(acno, am);
                    break;
                case 6:
                    System.out.print("Enter Account Number : ");
                    acno = s.nextLine();
                    System.out.print("Enter Deposit Amount : ");
                    am = s.nextInt();
                    withdraw(acno, am);
                    break;
                case 7:
                    System.out.print("Enter Account Number : ");
                    acno = s.nextLine();
                    applyInterestRate(acno);
                    break;
                default:
                    System.out.println("Invalid Choice !!");
                    break;
            }
        }

    }

    public static void listAllAccounts() {
        for (AbstractAccount account : accounts) {
            System.out.println("Account Number: " + account.accountNumber);
            System.out.println("Account Holder: " + account.accountHolderName);
            System.out.println("Account Type: " + account.getClass().getSimpleName());
            System.out.println("Balance: " + account.balance);
            System.out.println("-----------------------------");
        }
    }

    public static void addAccount(AbstractAccount account) {
        accounts.add(account);
    }

    public static void deposit(String accountNumber, double amount) {
        AbstractAccount account = findAccount(accountNumber);
        if (account != null) {
            account.deposit(accountNumber, amount);
        } else {
            System.out.println("Error: Account not found.");
        }
    }

    public static void withdraw(String accountNumber, double amount) {
        AbstractAccount account = findAccount(accountNumber);
        if (account != null && account instanceof WithdrawableAccount) {
            ((WithdrawableAccount) account).withdraw(accountNumber, amount);
        } else {
            System.out.println("Error: Account not found or does not support withdrawal.");
        }
    }

    public static void applyInterestRate(String accountNumber) {
        AbstractAccount account = findAccount(accountNumber);
        if (account != null) {
            account.applyInterest(accountNumber);
            System.out.println("Interest rate applied to account: " + account.accountNumber);
        } else {
            System.out.println("Error: Account not found.");
        }
    }

    public static AbstractAccount findAccount(String accountNumber) {
        for (AbstractAccount account : accounts) {
            if (account.accountNumber.equals(accountNumber)) {
                return account;
            }
        }
        System.out.println("Error: Account not found.");
        return null;
    }
}
