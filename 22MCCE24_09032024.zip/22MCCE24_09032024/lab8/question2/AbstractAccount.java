public abstract class AbstractAccount implements Account {
    String accountNumber ;
    String accountHolderName ;
    double balance;
    double interest = 0;

    public AbstractAccount(String accountNumber, String accountHolderName) {
        this.accountNumber = accountNumber;
        this.accountHolderName = accountHolderName;
        this.balance = 0.0;
    }

}
