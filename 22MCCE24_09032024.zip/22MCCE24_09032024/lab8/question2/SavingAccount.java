public class SavingAccount extends AbstractAccount implements WithdrawableAccount   {
    public SavingAccount(String accountNumber, String accountHolderName) {
        super(accountNumber, accountHolderName);
        interest = 5;
    }
    @Override
    public void deposit(String accountNumber ,double amount) {
        if ( accountNumber.equals(this.accountNumber))
        this.balance += amount;
        else System.out.println("Wrong Acount number");
    }
    
    @Override
    public double withdraw(String accountNumber, double amount) {
        if ( accountNumber.equals(this.accountNumber)){
            this.balance -= amount;
            return balance;}
            else {System.out.println("Wrong Acount number");return -1;}
        }
        
        @Override
    public void applyInterest(String accountNumber ) {
        if ( accountNumber.equals(this.accountNumber))
        this.balance += balance*interest;
        else System.out.println("Wrong Acount number");
    }

    
}
