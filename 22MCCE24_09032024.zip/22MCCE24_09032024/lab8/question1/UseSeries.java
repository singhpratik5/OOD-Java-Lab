//Pratik Singh : 22MCCE24
import java.util.Scanner;
public class UseSeries {
    public static void printSeries(Series a, int howmany) {
        a.reset();
        for (int i = 0; i < howmany; i++) {
            System.out.println("Next number in Series: " + a.getNext());
        }
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int ch1 = 1, ch2, num;
        while (ch1 != 0) {
            ch2 = 1;
            System.out.println("1. ByTwo\n2. ByThree\n3. Array\nEnter you Choice( 0 for exit ) : ");
            ch1 = s.nextInt();
            switch (ch1) {
                case 0:
                    break;
                case 1:
                    ByTwos two = new ByTwos();
                    ch2 = 1;
                    while (ch2 != 0) {
                        System.out.println(
                                "1. GetNext\n2. reset\n3. Setstart\n4. Printseries\nEnter Your choice ( 0 for exit ) : ");
                        ch2 = s.nextInt();
                        switch (ch2) {
                            case 0:
                                break;
                            case 1:
                                System.out.println(two.getNext());
                                break;
                            case 2:
                                two.reset();
                                break;
                            case 3:
                                System.out.print("Enter Start : ");
                                num = s.nextInt();
                                two.setStart(num);
                                break;
                            case 4:
                                System.out.print("Enter no. of elements : ");
                                num = s.nextInt();
                                printSeries(two, num);
                                break;
                            default:
                                System.out.println("Invalid choice");
                                break;
                        }
                    }
                    break;
                case 2:
                    ByThrees th = new ByThrees();
                    ch2 = 1;
                    while (ch2 != 0) {
                        System.out.println(
                                "1. GetNext\n2. reset\n3. Setstart\n4. Printseries\nEnter Your choice ( 0 for exit ) : ");
                        ch2 = s.nextInt();
                        switch (ch2) {
                            case 0:
                                break;
                            case 1:
                                System.out.println(th.getNext());
                                break;
                            case 2:
                                th.reset();
                                break;
                            case 3:
                                System.out.print("Enter Start : ");
                                num = s.nextInt();
                                th.setStart(num);
                                break;
                            case 4:
                                System.out.print("Enter no. of elements : ");
                                num = s.nextInt();
                                printSeries(th, num);
                                break;
                            default:
                                System.out.println("Invalid choice");
                                break;
                        }
                    }
                    break;
                case 3:
                    System.out.println("Enter Size of Array : ");
                    num = s.nextInt();
                    int[] a = new int[num];
                    System.out.println("Enter Common diff : ");
                    int dif = s.nextInt();
                    ArraySeries arr = new ArraySeries(num, dif);
                    ch2 = 1;
                    while (ch2 != 0) {
                        System.out.println(
                                "1. GetNext\n2. reset\n3. Setstart\n4. Printseries\nEnter Your choice ( 0 for exit ) : ");
                        ch2 = s.nextInt();
                        switch (ch2) {
                            case 0:
                                break;
                            case 1:
                                System.out.println(arr.getNext());
                                break;
                            case 2:
                                arr.reset();
                                break;
                            case 3:
                                System.out.print("Enter Start : ");
                                num = s.nextInt();
                                arr.setStart(num);
                                break;
                            case 4:
                                System.out.print("Enter no. of elements : ");
                                num = s.nextInt();
                                if (a.length < num) {
                                    System.out.println("Not possible");
                                } else
                                    printSeries(arr, num);
                                break;
                            default:
                                System.out.println("Invalid choice");
                                break;
                        }
                    }
                    break;
                default:
                    System.out.println("Invalid choice");
                    break;
            }
        }
    }
}
