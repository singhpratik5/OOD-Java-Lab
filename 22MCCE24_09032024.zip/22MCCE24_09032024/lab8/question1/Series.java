public interface Series
{
    int getNext();//Get the next number in the Series
    void reset();//Reset back to initial state
    void setStart(int x);//Start from x
    
}
