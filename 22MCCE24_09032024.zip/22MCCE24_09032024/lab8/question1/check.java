import java.util.Scanner;

public class check {
    public static void printSeries(Series a, int howmany) {
        a.reset();
        for (int i = 0; i < howmany; i++) {
            System.out.println("Next number in Series: " + a.getNext());
        }
    }

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        int ch1 = 1, ch2, num;
        while (ch1 != 0) {
            ch2 = 1;
            System.out.println("1. ByTwo\n2. ByThree\n3. Array\nEnter your Choice (0 for exit): ");
            ch1 = s.nextInt();
            switch (ch1) {
                case 0:
                    break;
                case 1:
                    ByTwos two = new ByTwos();
                    ch2 = 1;
                    while (ch2 != 0) {
                        System.out.println("1. GetNext\n2. reset\n3. Setstart\n4. Printseries\nEnter Your choice (0 for exit): ");
                        ch2 = s.nextInt();
                        switch (ch2) {
                            case 0:
                                break;
                            case 1:
                                System.out.println(two.getNext());
                                break;
                            case 2:
                                two.reset();
                                break;
                            case 3:
                                System.out.print("Enter Start: ");
                                num = s.nextInt();
                                two.setStart(num);
                                break;
                            case 4:
                                System.out.print("Enter no. of elements: ");
                                num = s.nextInt();
                                printSeries(two, num);
                                break;
                            default:
                                System.out.println("Invalid choice. Please try again.");
                        }
                    }
                    break;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }
}
