public class ArraySeries implements Series {
    private int[] arr;
    private int cur =0 ;
    public ArraySeries(){
        arr = new int[10];
    }
    public ArraySeries ( int n, int dif){
        arr = new int[n];
        for (int i = 0; i < n-1; i++) {
            arr[i+1] = arr[i] + dif;
        }
    }

    public int getNext(){
        if ( cur < arr.length){

            return arr[cur++];
        }
        else return -1;
    }
    public void reset(){
        cur = 0;
    }
    public void setStart(int x){
        if ( x < arr.length){
            cur = x;
        }
        else System.out.println("x is too large");
    }
}
